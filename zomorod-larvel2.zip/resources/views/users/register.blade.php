@extends('master')


@section('body')

<body>
<main id="root">
        <div class="container">
            <!-- ورود کاربران -->
            <div class="login-section panel">

            
            </div>
            <!-- ثبت نام کاربران  -->

            <div class="register-section panel">
            
            
            </div>


        </div>
    </main>

</body>

@endsection