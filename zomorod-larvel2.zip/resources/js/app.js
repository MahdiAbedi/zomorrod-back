import SearchPanel from './SearchPanel';
import PassengersInfo from './components/PassengersInfo';
import InternationalTicketResults from './components/Results/InternationalTicketResults';
import InternalTicketResults from './components/Results/InternalTicketResults';
import HotelResutls from './components/Results/Hotel/HotelResutls';
import RoomsList from './components/Results/Hotel/RoomsList';
import ChangeOulineTicket from './components/Results/ChangeOulineTicket';
import ChangeInlineTicket from './components/Results/ChangeInlineTicket';

const App = () => {
    return <div>APP</div>
}

// ReactDOM.render(<App />,document.querySelector('#root'));