
class TrainTicket extends React.Component{
    render(){
        return (
        <div className="form" id="TrainTicket"  style={{display:'none'}}>
            <h2>به زودی....</h2>
        </div>
        );
    }

}


export default TrainTicket;