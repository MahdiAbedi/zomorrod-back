class InsuranceTicket extends React.Component{
    render(){
        return (
        <div className="form" id="InsuranceTicket"  style={{display:'none'}}>
            <h2>به زودی....</h2>
        </div>
        );
    }

}
export default InsuranceTicket;