<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($tour->metadescription); ?>">
    <meta name="keywords" content="<?php echo e($tour->keywords); ?>">
    <link rel="canonical" href="<?php echo e(config('app.url')); ?>/tour/<?php echo e($tour->alias); ?>" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', $tour->title); ?>



<?php $__env->startSection('body'); ?>
    <!-- main part -->
    <main class="tourDetail">
        <!-- نمایش مراحل انتخاب و خرید -->
        <div class="container">
            <!-- مسیر سایت  -->
            <ul class="breadCrums">
                <li>
                    <a href="/">خانه</a>
                </li>
                <li>
                    <a href="/tours">تورهای خارجی</a>
                </li>
                <!-- ممکنه یک تور چندتا دسته بندی داشته باشه -->
                <?php $__currentLoopData = $tourCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="/tours/<?php echo e($category->alias); ?>"><?php echo e($category->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <li>
                    <a href="/tour/<?php echo e($tour->alias); ?>"><?php echo e($tour->title); ?></a>
                </li>
                
            </ul>

            <div class="tour_detail_top">
                <div class="tourSummary column">
                    <h1> <?php echo e($tour->title); ?> </h1>
                    <h3><?php echo e($tour->duration); ?></h3>
                    <span class="stars">
                        <?php for($i = 0; $i < $tour->star; $i++): ?>
                            <i class="fa fa-star green"></i>
                        <?php endfor; ?>
                        <?php for($i = 0; $i < 5- $tour->star; $i++): ?>
                            <i class="far fa-star green"></i>
                        <?php endfor; ?>
                        
                    </span>
                    <p><?php echo e($tour->after_title); ?></p>
                    <small>ایرلاین:<?php echo e($tour->airline); ?></small>
                    <table class="rounded_table">
                        <thead>
                            <tr>
                                <th>تاریخ رفت</th>
                                <th>تاریخ برگشت</th>
                            </tr>
                        </thead>
                        <tr>
                            <td name="date"><?php echo e($tour->departure_time); ?></td>
                            <td name="date"><?php echo e($tour->return_time); ?></td>
                        </tr>

                    </table>
                    <table class="rounded_table">
                        <thead>
                            <tr>
                                <th>تور پذیرای </th>
                            </tr>
                        </thead>
                        <tr>
                            <td>بزرگسالان و کودکان میباشد</td>
                        </tr>

                    </table>

                    <div class="tourPrice">
                        <p>شروع قیمت برای <?php echo e($tour->duration); ?> از :</p>
                        <p class="money"><?php echo e($tour->price); ?> <small><?php echo e($tour->price_currency); ?></small></p>
                    </div>
                </div>
                <div class="slideShow">
                    <div class="slideshow-container">

                    <?php
                        $images = explode(',',$tour->gallery)
                    ?>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mySlides">
                            <img src="<?php echo e($image); ?>" alt="<?php echo e($tour->title); ?>" style="width:100%">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <a class="prev" onclick="plusSlides(-1, 0)">&#10094;</a>
                        <a class="next" onclick="plusSlides(1, 0)">&#10095;</a>
                      </div>
                </div>
                
            </div>

        </div>

        <div class="container anchor">
            <div class="anchors">
                <a href="#services">خدمات</a>
                <a href="#TourInfo">اطلاعات تور</a>
                <a href="#TourPlan">برنامه سفر</a>
                <a href="#TourPlan">راهنمای سفر</a>
                <a href="#Madarek">مدارک مورد نیاز</a>
                <a href="#Reviews">دیدگاه مسافران</a>
            </div>

            <!-- <a class="btn btn-zgreen">
                رزرو تور
            </a> -->
        </div>
        <!-- خدمات  -->
        <div class="container panel tourOptions" id="services">
            <h3 class="green">. خدمات</h3>
            <?php
                $facilities = explode(',',$tour->facilities)
            ?>
            <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="/img/icons/tour/<?php echo e($facility); ?>.jpg" alt="<?php echo e($facility); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
       
        <!-- مدارک مورد نیاز -->
        <?php
            $madarek = explode(',',$tour->madarek)
        ?>

        <?php if($tour->madarek): ?>
        <div class="container panel tourOptions"  id="Madarek">
            <h3 class="green">. مدارک مورد نیاز</h3>
           
            <ul class="links">
                <?php $__currentLoopData = $madarek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $madrak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($madrak); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
       
        <!-- راهنمای سفر -->
        <div class="container panel"  id="Guid">
            <h3 class="green">. راهنمای سفر</h3>
            <p></p>
            <?php echo $tour->description; ?>

        
        </div>


            <!-- برنامه سفر -->
            <?php
                $hotels = json_decode($tour->hotels);
            ?>
            <?php if($hotels): ?>
                 <!-- اطلاعات هتل  -->
                    <div class="container">
                        <table class="rounded_table">
                            <thead>
                                <th>نام هتل</th>
                                <th>تعداد ستاره</th>
                                <th>هر نفر در اتاق 1 تخته</th>
                                <th>هر نفر در اتاق 2 تخته</th>
                                <th>کودک با تخت</th>
                                <th>کودک بدون تخت</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo $hotel->name; ?></td>
                                        <td> 
                                        <span class="stars">
                                            <?php for($i = 0; $i < $hotel->star; $i++): ?>
                                                <i class="fa fa-star green"></i>
                                            <?php endfor; ?>
                                            <?php for($i = 0; $i < 5- $hotel->star; $i++): ?>
                                                <i class="far fa-star green"></i>
                                            <?php endfor; ?>
                                            
                                        </span>
                                        </td>
                                        <td><?php echo e($hotel->single); ?> <?php echo e($hotel->currency); ?></td>
                                        <td><?php echo e($hotel->double); ?> <?php echo e($hotel->currency); ?></td>
                                        <td><?php echo e($hotel->child_with_bed); ?> <?php echo e($hotel->currency); ?></td>
                                        <td><?php echo e($hotel->child_no_bed); ?> <?php echo e($hotel->currency); ?></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
            <?php endif; ?>


            <?php
                $services = explode(',',$tour->services)
            ?>

            <?php if($tour->services): ?>
         <!-- ما چه خدماتی به شما در این تور ارائه می‌دهیم؟  -->
         <div class="container panel tourOptions"  id="Madarek">
            <h3 class="green">. ما چه خدماتی به شما در این تور ارائه می‌دهیم؟ </h3>
            
            <ul class="links">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($service); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
        <?php endif; ?>



        <!-- مدارک مورد نیاز -->
        <?php
            $roles = explode(',',$tour->roles)
        ?>

        <?php if($tour->roles): ?>
        <div class="container panel tourOptions"  id="Madarek">
            <h3 class="green">. تذکرات</h3>
           
            <ul class="links">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($role); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>



        <!-- برنامه سفر -->
        <?php
            $schedules = json_decode($tour->schedule);
        ?>
        <?php if($schedules): ?>
        <div class="container panel" id="TourPlan">
            <h3 class="green">. برنامه سفر</h3>

            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="accordion"><span class="title"><?php echo e($schedule->title); ?> :</span><?php echo e($schedule->plan); ?></button>
                <div class="accordionbody">
                    <div class="accordionText clearfix">
                        <?php if(isset($schedule->img)): ?>
                            <img src="<?php echo e($schedule->img); ?>" alt="" >
                        <?php endif; ?>
                        <p><?php echo html_entity_decode($schedule->description); ?></p>
                        
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<style>
    .mySlides{display: none;height: 100%;}
    img {vertical-align: middle;height: 100%;object-fit: cover;border-radius: 4px;}
    
    /* Slideshow container */
    .slideshow-container {
      max-width: 1000px;
      position: relative;
      margin: auto;
      height: 100%;
    }
    
    /* Next & previous buttons */
    .prev, .next {
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      padding: 16px;
      margin-top: -22px;
      color: white;
      font-weight: bold;
      font-size: 18px;
      transition: 0.6s ease;
      border-radius: 0 3px 3px 0;
      user-select: none;
    }
    
    /* Position the "next button" to the right */
    .next {
      left: 0;
      border-radius: 3px 0 0 3px;
    }
    
    /* On hover, add a grey background color */
    .prev:hover, .next:hover {
      background-color: #f1f1f1;
      color: black;
    }
</style>
    <script>
    var slideIndex = [1,1];
    var slideId = ["mySlides"]
    showSlides(1, 0);
    showSlides(1, 1);
    
    function plusSlides(n, no) {
      showSlides(slideIndex[no] += n, no);
    }
    
    function showSlides(n, no) {
      var i;
      var x = document.getElementsByClassName(slideId[no]);
      if (n > x.length) {slideIndex[no] = 1}    
      if (n < 1) {slideIndex[no] = x.length}
      for (i = 0; i < x.length; i++) {
         x[i].style.display = "none";  
      }
      x[slideIndex[no]-1].style.display = "block";  
    }
</script>

<script>
    var acc = document.getElementsByClassName("accordion");
    var i;
    
    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.maxHeight) {
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + "px";
        } 
      });
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zomorod-larvel2\resources\views/pages/tours/detail.blade.php ENDPATH**/ ?>