<?php echo $__env->make('includes/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
    <!-- منوی بالا -->
    <?php echo $__env->make('includes/topMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- نمایش پیامهای خطا و ... در بالای صفحات  -->
    <?php echo $__env->make('layouts/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php echo $__env->yieldContent('body'); ?>


    
    <!-- منوی پایین -->
    <?php echo $__env->make('includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\zomorod-larvel2\resources\views/master.blade.php ENDPATH**/ ?>