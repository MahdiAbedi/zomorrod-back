<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($tourCategory->metaDescription); ?>">
    <meta name="keywords" content="<?php echo e($tourCategory->keywords); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', $tourCategory->name); ?>
<?php $__env->startSection('body'); ?>
<main>
        <!-- نمایش مراحل انتخاب و خرید -->
        <div class="container">
            <ul class="breadCrums">
                <li>
                    <a href="/">خانه</a>
                </li>
                <li>
                    <a href="/tours">تورهای خارجی</a>
                </li>
                <li>
                    <a href="/tours/<?php echo e($tourCategory->alias); ?>"><?php echo e($tourCategory->name); ?></a>
                </li>
                
            </ul>
        </div>
        <!-- بخش نمایش نتایج جستجو -->
        <section class="result-panel container">
            <!-- فیلترها -->
            <aside class="filters">
                <section class="flex bg-zgreen">
                    <p>تورهای محبوب</p>
                </section>
                <!-- جستجوی هتل -->
                <!-- blog -->
                <?php $__currentLoopData = $randomTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $random): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="blog-slider style2" href="/tour/<?php echo e($random->alias); ?>">
                        <img src="<?php echo e($random->thumbnail); ?>" alt="<?php echo e($random->title); ?>">
                        <h2><?php echo e($random->title); ?><p><?php echo e($random->duration); ?></p></h2>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <!-- <section class="flex bg-zgreen">
                    <p>مقالات مرتبط</p>
                </section> -->
                <!-- جستجوی هتل -->
               
                <!-- blog -->
                <!-- <a class="blog-slider" href="#">
                    <img src="img/tours/img-8.jpg" alt="">
                    <h2>تور بلغارستان "وارنا"</h2>
                </a> -->
                
            </aside>

            <!-- نتایج -->
            <section class="results ">
                <!-- قسمت مرتبط سازی نتایج بر اساس قیمت و.. و نمایش تاریخ -->
                <?php
                    $tags = explode(',',$tourCategory->tags)
                ?>

                <?php if($tourCategory->tags): ?>
                <section>
                        <ul class="tags">
                            
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/tour-tags/<?php echo e($tag); ?>" class="tag"><?php echo e($tag); ?></a></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                </section>
                <?php endif; ?>
                <!-- بخش نمایش تیکت ها -->
                <section class="hotels">
                    <div class="hotel-container bg-zgreen tourCatTitle">
                        <h1><?php echo e($tourCategory->name); ?></h1>
                    </div>
                    <!-- یک تیکت تک -->
                    <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hotels-container tour-result">
                            <img src="<?php echo e($tour->thumbnail); ?>" alt="<?php echo e($random->title); ?>">
                            <div class="hotels_preview flex-column">
                                <div class="hotels_preview_top">
                                <div class="parts">
                                    <div class="right">
                                        <h2 class="green"><?php echo e($tour->title); ?></h2>
                                        <span class="stars">
                                            <i class="fa fa-star green"></i>
                                            <i class="fa fa-star green"></i>
                                            <i class="fa fa-star green"></i>
                                            <i class="far fa-star green"></i>
                                            <i class="far fa-star green"></i>
                                        </span>
                                        <p>رتبه : 7.3 | خوب |</p>
                                    
                                    </div>
                                    <div class="">
                                        <P><span class="green">مدت اقامت:</span><?php echo e($tour->duration); ?></P>
                                        <P><span class="green">رفت:</span>Atlas Air</P>
                                        <P><span class="green">برگشت:</span>Iran Air</P>
                                    </div>
                                </div>
                                    <div class="price">
                                        <span>شروع قیمت از:<p class="green money" name="money"><?php echo e($tour->price); ?> <?php echo e($tour->price_currency); ?></p></span>
                                        
                                    </div>
                                </div>
                                <div class="tour_facilities">
                                    <p>هتل</p>
                                    <p>صبحانه</p>
                                    <p>ترانسفر </p>
                                    <p>بیمه</p>
                                    <p>سیم کارت</p>
                                    <p></p>
                                </div>
                                <a href="/tour/<?php echo e($tour->alias); ?>" class="hotels_detail green">
                                    مشاهده تور
                                </a>
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            </section>


        </section>
        <section class="panel container">
                <header class="panel-title flex-between">
                    <span><?php echo e($tourCategory->name); ?></span>
                    <a href="#"><i class="fas fa-chevron-down"></i></a>
                </header>
                <div class="panel-body">
                <?php echo $tourCategory->description; ?>

                </div>

            </section>
    </main>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zomorod-larvel2\resources\views/pages/tours/tourCategoryLanding.blade.php ENDPATH**/ ?>